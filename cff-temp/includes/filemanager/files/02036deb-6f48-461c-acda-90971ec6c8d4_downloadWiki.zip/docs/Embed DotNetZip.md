# Emebd DotNetZip into your application

Suppose you want to create an app, a WinForms app or command-line app.  You like the features of DotNetZip, but you don't want to redistribute a DLL with your app; you want to redistribute the app as a single EXE.  You looked at the options, and for whatever reason you do not want to use [ILMerge](http://www.microsoft.com/Downloads/details.aspx?familyid=22914587-B4AD-4EAE-87CF-B14AE6A939B0&displaylang=en).  (One possible reason is that it is difficult to use ILMerge with signed assemblies, like DotNetZip. You need to strip the signature in order to use ILMerge). 

An alternative to ILMerge is to simply add the DLL as an embedded resource into the exe itself, and then load the DLL from the embedded stream at runtime.  

You'd add a reference to the DLL as normal.  One key additional step is required: you must also physically add the DLL as an item in your project, with "Add Existing Item..." And you need to mark that item as "Embedded Content."   The DLL itself will then become an embedded resource in your EXE.  Then you add the following boilerplate code to your app:  two static methods on your main class.  

That's it.  Easy peasy.  

{{
    // static constructor to add a handler to the AssemblyResolve event 
    static MainClass()  //   <--- this must be the name of your main class
    {
        AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(Resolver);
    }

    static System.Reflection.Assembly Resolver(object sender, ResolveEventArgs args)
    {
        Assembly a1 = Assembly.GetExecutingAssembly();
        Stream s = a1.GetManifestResourceStream("Ionic.Zip.dll");
        byte[]() block = new byte[s.Length](s.Length);
        s.Read(block, 0, block.Length);
        Assembly a2 = Assembly.Load(block);
        return a2;
    }

    ....

}}


This technique works with any DLL of course.  It is not specific to DotNetZip. 

