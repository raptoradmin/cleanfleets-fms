# DotNetZip Examples 

* [C# Examples ](-CS-Examples)
* [VB Examples ](-VB-Examples)
* [Using LINQ With DotNetZip (C#)](DotNetZip-Linq-Csharp)
* [Using LINQ With DotNetZip (VB)](_DotNetZip-LINQ-VB)
* [ASP.NET Example, in C#](ASPNET-Example-1)
* [ASP.NET Example, in VB](ASPNET-Example-2)
* [Powershell Examples ](-PS-Examples)
* [Embedding the DotNetZip DLL into your application ](-Embed-DotNetZip)
* [Embedding zipped content into your application ](-Embed-Zipped-Content)

