# Full Documentation is Available

[Reference doc](http://dotnetzip.herobo.com/DNZHelp/Index.html)
[Lots of examples ](-Examples) , for VB, C#, Powershell, and so on. 
