# Examples for using DotNetZip from within Powershell scripts

To use these from the command line, you will need to save them to a file, probably something that ends with .ps1.  To run the script, use something like {"powershell  .\CreateZip.ps1"}.  Be sure to use a full pathname for that script. 


**Read a Zip file from within Powershell** - Be sure to call Dispose() at the end or the zipfile will remain open (locked). 
{{
$SourceFile = "c:\files\filename.zip" 
[System.Reflection.Assembly](System.Reflection.Assembly)::LoadFrom("c:\Files\Ionic.Zip.dll") 
$zipfile = [Ionic.Zip.ZipFile](Ionic.Zip.ZipFile)::Read($sourceFile) 
foreach($file in $zipfile) 
    {$file.FileName} 
$zipfile.Dispose() 
}}

**Zip up a folder from within Powershell** - zip an entire directory
{{
    [System.Reflection.Assembly](System.Reflection.Assembly)::LoadFrom("c:\\bin\\Ionic.Zip.dll");

    $directoryToZip = "c:\\directoryToZip"
    $zipfile = new-object Ionic.Zip.ZipFile
    $e = $zipfile.AddDirectory($directoryToZip, "home")
    $zipfile.Save("ZipFiles.ps1.out.zip")
    $zipfile.Dispose()
}}


**Create an AES-encrypted zipfile from within Powershell** 
{{
    [System.Reflection.Assembly](System.Reflection.Assembly)::LoadFrom("c:\\bin\\Ionic.Zip.dll");

    $directoryToZip = "c:\\temp"
    $zipfile =  new-object Ionic.Zip.ZipFile
    $zipfile.Encryption = [Ionic.Zip.EncryptionAlgorithm](Ionic.Zip.EncryptionAlgorithm)::WinZipAes256
    $zipfile.Password = "Albatros$"    
    $e= $zipfile.AddDirectory($directoryToZip, "home")
    $zipfile.Save("ZipFiles.ps1.out.zip")
    $zipfile.Dispose()
}}


**Create a zipfile, and include content from a string** - This sample shows the AddEntry() method, which adds an entry to the zip archive, using content from a string. 
{{
    [System.Reflection.Assembly](System.Reflection.Assembly)::LoadFrom("c:\\bin\\Ionic.Zip.dll");

    $directoryToZip = "c:\\home"
    $zipfile =  new-object Ionic.Zip.ZipFile
    $e= $zipfile.AddEntry("Readme.txt", "", "This content will appear in a file, within the zip")
    $e= $zipfile.AddDirectory($directoryToZip, "home")
    $zipfile.Save("ZipFiles.ps1.out.zip")
    $zipfile.Dispose()
}}

**Create a zip, adding selected files, and using AES** - this script shows the use of the AddSelectedFiles() call, which allows an app to specify criteria for including or excluding files into a zip.  The criteria shown in this example is just the filename, but you can also add in files that have specific  file attributes (eg, the archive bit is set), or files with a last modified time within a certain range, or files within a size range, or a logical combination of those criteria.  
{{
    [System.Reflection.Assembly](System.Reflection.Assembly)::LoadFrom("c:\\bin\\Ionic.Zip.dll")

    $directoryToZip = "c:\\dev\\powershell"
    $zipfile =  new-object Ionic.Zip.ZipFile
    $zipfile.Encryption = [Ionic.Zip.EncryptionAlgorithm](Ionic.Zip.EncryptionAlgorithm)::WinZipAes256
    $zipfile.Password = "Albatros$"
    $e= $zipfile.AddEntry("Readme.txt", "", "This is a zipfile created from within powershell.")
    $e= $zipfile.AddSelectedFiles("name != *.zip", $directoryToZip, "home")
    $zipfile.Save("ZipFiles.ps1.out.zip")
    $zipfile.Dispose()
}}

