# Use LINQ with DotNetZip

**Select Entries that start with a given letter**
{{
using (var zip = ZipFile.Read(ArchiveToRead))
{
    Console.WriteLine("\nQuerying (StartsWith(C))...");
    var selection = from e in zip.Entries
        where System.IO.Path.GetFileName(e.FileName).StartsWith("C")
        select e;

    foreach (var e in selection)
        Console.WriteLine(e.FileName);
}
}}

**Select Entries with UncompressedSize over a given value**
{{
using (var zip = ZipFile.Read(ArchiveToRead))
{
    Console.WriteLine("\nQuerying (UncompressedSize < 1024)...");
    selection = from e in zip.Entries
        where e.UncompressedSize < 1024
        select e;

    foreach (var e in selection)
        Console.WriteLine(e.FileName);
}
}}


**Query for the entries that use encryption**  
{{
using (var zip = ZipFile.Read(ArchiveToRead))
{
    Console.WriteLine("\nQuerying (UsesEncryption = true)...");
    selection = from e in zip.Entries
        where e.UsesEncryption
        select e;

    foreach (var e in selection)
        Console.WriteLine(e.FileName);
}
}}

**Group entries by filename** - get size of largest entry with the given filename. 
{{
  using (var zip = ZipFile.Read(zipPath))
  {
      var selection = 
          from e in zip
          group e by System.IO.Path.GetFileName(e.FileName) into g
          select new {
                        Name = g.Key,
                        LargestSize = g.Max(e => e.UncompressedSize)
          };

     foreach (var s in selection)
         Console.WriteLine("{0}", s.ToString());
  }
}}

**Group entries by short name, extract the largest of each group**
{{
using (var zip = ZipFile.Read(zipPath))
{
    var groups = 
        from e in zip
        group e by System.IO.Path.GetFileName(e.FileName);

   foreach (var elt in groups)
   {
       Console.WriteLine("{0}", elt.Key);
       var largest = (from e in elt
           where e.UncompressedSize == elt.Max(entry => entry.UncompressedSize)
           select e)
           .First();
       Console.WriteLine("    {1,8}  {0}", largest.FileName, largest.UncompressedSize);
       largest.Extract();
   }
}
}}

**Similar to the above, but with a single query**
{{
using (var zip = ZipFile.Read(zipPath))
{
    var selection = 
        from e in zip
        group e by System.IO.Path.GetFileName(e.FileName) into g
        select new {
                ShortName = g.Key,
                LargestSize =  g.Max(ex2 => ex2.UncompressedSize),
                Entry = g.Where(ex1 => ex1.UncompressedSize == g.Max(ex2 => ex2.UncompressedSize)).First()
                }
        ;

    foreach (var x in selection)
    {
        Console.WriteLine("    {1,8}  {0}", x.Entry.FileName, x.Entry.UncompressedSize);
        if (x.Entry.UncompressedSize > 0)
        {
            x.Entry.FileName = x.ShortName;
            x.Entry.Extract("queryzip");
        }
    }
}
}}

**Select filesystem files to add to an archive**
{{
using (var zip = new ZipFile())
{
    // select the 8 largest .xlsx files
    var fileInfos = (from fi in (from fn in Directory.GetFiles(".", "*.xlsx")
                             select new FileInfo(fn))
                             orderby fi.Length descending
                             select fi).Take(8);

    // convert from a List<FileInfo> to a List<string> filename 
    var filesToZip = fileInfos.ToList().ConvertAll((fi)=>fi.Name);
    zip.AddFiles(filesToZip);
    zip.Save(archiveName);
}
}}

**Another example for selecting filesystem files to add to an archive**
{{
using (var zip = new ZipFile())
{
    // select the 10 most recently modified .pdf files
    var fileNames = (from fn in Directory.GetFiles(".", "*.pdf")
                orderby File.GetLastWriteTimeUtc(fn)  descending
                select fn).Take(10);

    zip.AddFiles(fileNames);
    zip.Save(archiveName);
}
}}

**Select only non-hidden filesystem files to add to an archive**
{{
using (var zip = new ZipFile())
{
    // select only non-hidden files 
    var fileNames = (from fn in Directory.GetFiles(".", "**.**", SearchOption.AllDirectories)
                where ((File.GetAttributes(fn) & FileAttributes.Hidden) == 0)
                select fn).ToList();
    zip.AddFiles(fileNames);
    zip.Save(archiveName);
}
}}


