# Embedding Zipped Content with DotNetZip

Suppose the design of your application requires you to embed a set of content into the EXE.  Maybe there are text files, script files, language translations, and so on.  If you embed these into the zip as individual units, you can have many resource streams, and the content is not compressed.

An alternative is to bundle those embedded resources into a zip file, and then embed the zipfile into your application.  At runtime, rather than retrieving the embedded items as individual resource streams, you would retrievve the zipfile, and then read the content of each item from the zip file.  

Because Ionic.Zip can easily read a zip file from a stream, you can use the following code to, first, read the zip from the embedded resource, and second, to read and extract the content from the embedded zip. 

{{

    private System.IO.Stream GetEmbeddedStream(string name)
    {
        // The name of the embedded resource often uses the project name as a prefix.
        // This is set in the project properties page in VS2008. 
        string embeddedName = String.Format("WebifyChm.{0}", name);
        var myself = Assembly.GetExecutingAssembly();
        return myself.GetManifestResourceStream(embeddedName);
    }


    private void UnzipTemplateContent()
    {
        bool wantOverwrite = false;
        using (Stream s = GetEmbeddedStream("ChmWeb.zip"))
        {
            using (Ionic.Zip.ZipFile zip = Ionic.Zip.ZipFile.Read(s))
            {
                foreach (Ionic.Zip.ZipEntry entry in zip)
                {
                    this.StatusUpdate("Extracting {0}", entry.FileName);
                    entry.Extract(this.targetDir, wantOverwrite);
                }
            }
        }
    }

}}

Very simple, very easy. 

Doing this - compressing the embedded content and de-compressing at runtime - makes sense when the content is compressible, and when either Ionic.Zip.dll is already in use, or when the size of the zip library is smaller than the net savings from compressing the embedded content.  

It's fast enough that speed will not be an issue in most cases. 
